package id.co.skyforce.bankponsel.model;

public class DummyModel {

	
}
